﻿global using SFML.Graphics;
global using SFML.Audio;
global using SFML.System;
global using SFML.Window;
global using Textboxes;
global using Lines;
global using SfmlAppLib;
global using Graphs;