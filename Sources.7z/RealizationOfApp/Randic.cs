﻿
namespace RealizationOfApp
{
    public static class Randic
    {
        public static Random random = new();
    }
}
