﻿using Matrixs;
using Graphs;
using RealizationOfApp;

namespace Lines
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //IEnumerable<int> weights;
            //IEnumerable<IEnumerable<string>> ways;
            //Graph graph = new();
            //graph.AddVertex("a");
            //graph.AddVertex("b");
            //graph.AddVertex("c");
            //graph.AddVertex("d");
            //graph.AddVertex("e");
            //graph.AddVertex("f");
            //graph["a", "b"] = 5;
            //graph["a", "c"] = 10;
            //graph["a", "d"] = 13;
            //graph["b", "c"] = 8;
            //graph["b", "d"] = 9;
            //graph["b", "e"] = 13;
            //graph["c", "d"] = 5;
            //graph["c", "e"] = 3;
            //graph["c", "f"] = 6;
            //graph["d", "e"] = 8;
            //graph["d", "f"] = 10;
            //graph["e", "f"] = 9;
            //ways = graph.Deikstra("a", out weights);
            //IEnumerator<int> enumerator = weights.GetEnumerator();
            //enumerator.MoveNext();
            //foreach (IEnumerable<string> way in ways)
            //{
            //    bool flag = false;
            //    foreach (string name in way)
            //    {
            //        Console.Write($"{(flag ? " -> " : "")}{name}");
            //        flag = true;
            //    }
            //    
            //    enumerator.MoveNext();
            //}
            //
            //Graph graph2 = new Graph();
            //graph2.IsOriented = false;
            //graph2.AddVertex("a");
            //graph2.AddVertex("b");
            //graph2.AddVertex("c");
            //graph2.AddVertex("d");
            //graph2.AddVertex("e");
            //graph2.AddVertex("f");
            //graph2["a", "b"] = 1;
            //graph2["a", "c"] = 1;
            //graph2["b", "f"] = 1;
            //graph2["b", "e"] = 1;
            //graph2["b", "d"] = 1;
            //graph2["c", "e"] = 1;
            //graph2["c", "f"] = 1;
            //graph2["d", "f"] = 1;
            //graph2["d", "e"] = 1;
            //graph2["e", "f"] = 1;
            //IEnumerable<string> maxClick = new string[0];
            //foreach (IEnumerable<string> set in graph2.ClicksOfGraph())
            //{
            //    if(set.Count()>maxClick.Count())
            //    {
            //        maxClick = set;
            //    }
            //}
            //Console.Write("{");
            //foreach (string s in maxClick)
            //{
            //    Console.Write($" {s} ");
            //}
            //Console.Write("}");
            //Graph graph3 = new();
            //graph3.AddVertex("a");
            //graph3.AddVertex("b");
            //graph3.AddVertex("c");
            //graph3.AddVertex("d");
            //graph3.AddVertex("e");
            //graph3.AddVertex("f");
            //graph3["a", "b"] = 1;
            //graph3["b", "a"] = 1;
            //graph3["c", "d"] = 1;
            //graph3["c", "e"] = 1;
            //graph3["d", "c"] = 1;
            //graph3["d", "e"] = 1;
            //graph3["e", "c"] = 1;
            //graph3["e", "d"] = 1;
            //graph3["f", "a"] = 1;
            //graph3["f", "c"] = 1;
            //foreach (IEnumerable<string> component in graph3.GetComponentsOfConnection())
            //{
            //    Console.Write("{");
            //    foreach (string s in component)
            //    {
            //        Console.Write($" {s} ");
            //    }
            //    
            //}
            //Graph graph4 = new();
            //graph4.IsOriented = false;
            //graph4.AddVertex("a");
            //graph4.AddVertex("b");
            //graph4.AddVertex("c");
            //graph4.AddVertex("d");
            //graph4.AddVertex("e");
            //graph4["a", "b"] = 3;
            //graph4["a", "e"] = 1;
            //graph4["c", "d"] = 3;
            //graph4["c", "b"] = 4;
            //graph4["b", "d"] = 3;
            //graph4["b", "e"] = 2;
            //graph4["d", "e"] = 4;
            //
            //Graph ostov = graph4.GetMinimunFrame();
            //
            Application mainWindow = new();
            mainWindow.Start();
        }
    }
}