﻿global using SFML.Graphics;
global using SFML.System;
global using SFML.Window;